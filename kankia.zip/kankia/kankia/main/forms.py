from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, TextAreaField, TextAreaField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length
from flask_wtf.file import FileAllowed, FileField

class Upload(FlaskForm):
    file_field = FileField('Json File', validators=[])
    submit = SubmitField('Upload')
