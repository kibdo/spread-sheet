import os
def upload_json_file(file_data, path):
    filename = file_data.filename
    file_data.save(os.path.join(path, filename))
    return filename