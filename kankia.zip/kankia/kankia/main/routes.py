from flask import Blueprint, flash, request, render_template, flash, redirect, url_for, abort, request
from kankia import app
from flask_login import login_required
from flask_login import current_user
from flask import jsonify
from.forms import Upload
from.utils import upload_json_file
import json
import os
main = Blueprint('main', __name__, template_folder='templates')

@main.route('/upload/', methods=['GET', 'POST'])
def upload():
    form = Upload()
    if request.method == 'POST':
        files_list = request.files.getlist('file_field')
        file_upload_path = os.path.join(app.root_path, 'static', 'uploads', 'jsons')
        for i in files_list:
            upload_json_file(i, file_upload_path)
        flash('File upload successful', category='success')
    return render_template('main/upload.html', form=form)
@main.route('/json/<filename>/delete/', methods=['GET', 'POST'])
def delete_json_file(filename):
    os.remove(os.path.join(app.root_path, 'static', 'uploads', 'jsons', f'{filename}'))
    return redirect(url_for('main.json_folder_list'))
@main.route('/', methods=['GET', 'POST'])
def json_folder_list():
    json_files = os.listdir(os.path.join(app.root_path, 'static', 'uploads', 'jsons'))
    
    return render_template('main/json-folder-files-list.html', json_files=json_files)

@main.route('/json/<filename>/save/', methods=['GET', 'POST'])
def save_json(filename):
    json_data = json.loads(request.form['data'])
    json_file_path = os.path.join(app.root_path, 'static', 'uploads', 'jsons', f'{filename}')
    with open(os.path.join(app.root_path, 'static', 'uploads', 'jsons', f'{filename}'), 'w') as f:
        json.dump(json_data,f, indent=2)
    return jsonify({'error': 'An error occcured while saving table', 'success': 'Table saved successfully'})


@main.route('/json/files/', methods=['GET', 'POST'])
def json_files():
    json_files_in_dir= []
    files_dir = os.listdir(os.path.join(app.root_path, 'static', 'uploads', 'jsons'))
    for i in files_dir:
        _, ext = os.path.splitext(i)
        if ext == '.json':
            json_files_in_dir.append(i)
    return render_template('/main/test.html', json_files_in_dir= json_files_in_dir)

@main.route('/json/<filename>/get_json/', methods=['GET', 'POST'])
def get_json_file(filename):
    json_file_path = os.path.join(app.root_path, 'static', 'uploads', 'jsons', f'{filename}')
    with open(json_file_path) as f:
        rows = json.load(f)
        columns = []
        column_keys = rows[1].keys()
        for i in column_keys:
            col_dict = {
                'name': f"{i}",
                'header': f"{i.capitalize()}",
            }
            columns.append(col_dict)
        columns.append({ 'markup': '<button id = \"delete-row\" title=\"delete this row\">X</button>', 'tabStop': 'true' })
        columns = json.dumps(columns)
        rows = json.dumps(rows)
    return jsonify({'columns': columns, 'rows': rows, 'filename': filename})
