from flask import Flask
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

app = Flask(__name__)
app.config['SECRET_KEY'] = 'kjkjk3j2kjK3jk24k2jj2kkhj2k'

from kankia.main.routes import main

#Blueprints
app.register_blueprint(main)